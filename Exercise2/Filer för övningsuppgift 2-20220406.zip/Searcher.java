import java.util.Collection;

public class Searcher {

	public Searcher(Collection<Recording> data) {
		
		Collection<Recording> recordings = data;

	}
}

