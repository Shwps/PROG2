
public interface Stats {

	long numberOfArtists();

	long numberOfGenres();

	long numberOfTitles();
}
