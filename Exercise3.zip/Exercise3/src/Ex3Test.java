import java.io.IOException;

public class Ex3Test {
    public static void main(String[] args){
        Exercise3 t = new Exercise3();
        try{
            t.importRecordings("recording_input.txt");
        } catch (IOException e){
            System.out.print("Error2");
        }

        System.out.print(t.getRecordings());


    }
}


